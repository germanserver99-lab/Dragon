"""Conservative data merge for Dragon Nest 556. Never replaces a base row."""
from pathlib import Path
from collections import Counter, defaultdict
import csv, hashlib, json, math, shutil
from dnt import DNT
ROOT=Path(__file__).parent; SOURCES=ROOT/'sources'; OUT=ROOT/'result'; EXT=OUT/'ext'; REPORT=OUT/'report'
DONORS=['ext2','ext']; BASE='ext556'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def csvwrite(name,rows,fields):
 with (REPORT/name).open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fields);w.writeheader();w.writerows(rows)
def group_identity(v):return tuple(v[n] for n in ['_ListID','_CompoundGroupID','_MainCategory','_CompoundGroupType','_JobClass'])
def deps(v):
 return [v['_SuccessItemID1']]+[v[x] for x in ['_FailItemID1','_SuccessAwardItem1'] if v[x]>0]+[v[f'_Slot{i}Id'] for i in range(1,6) if v[f'_Slot{i}Id']>0 and v[f'_Slot{i}Num']>0]
def refs(row):return [row.get(f'_TypeParam{i}',0) for i in range(1,4)]+[row.get(f'_Potential{i}',0) for i in range(1,11)]
OUT.mkdir(exist_ok=True);REPORT.mkdir(exist_ok=True)
shutil.copytree(SOURCES/BASE/'ext',EXT,dirs_exist_ok=True)
craft={s:{p.name:DNT(p) for p in sorted((SOURCES/s/'ext').glob('itemcompound*.dnt'))} for s in [BASE]+DONORS}
items={};itemloc={};itemdups=[]
for p in sorted((SOURCES/BASE/'ext').glob('itemtable*.dnt')):
 d=DNT(p)
 assert not d.duplicates, p
 for k,v in d.rows.items():
  if k in items:itemdups.append({'id':k,'first_table':itemloc[k],'second_table':p.name,'different':items[k]!=v})
  items[k]=v;itemloc[k]=p.name
recipes={k:(name,v) for name,d in craft[BASE].items() if name.startswith('itemcompoundtable') for k,v in d.rows.items()}
assert sum(len(d.rows) for n,d in craft[BASE].items() if n.startswith('itemcompoundtable'))==len(recipes)
base_recipe_ids=set(recipes)
base_recipe_count=len(recipes)
base_groups=[(n,k,v) for n,d in craft[BASE].items() if n.startswith('itemcompoundgrouptable') for k,v in d.rows.items()]
allgroups=[(s,n,k,v) for s in [BASE]+DONORS for n,d in craft[s].items() if n.startswith('itemcompoundgrouptable') for k,v in d.rows.items()]
available_groupids={v['_CompoundGroupID'] for s,n,k,v in allgroups}
shop_recipe_ids={v['_ItemCompoundID'] for d in craft[BASE].values() if d.path.name.startswith('itemcompoundshoptable') for v in d.rows.values()}
potential_pairs=set();potential_ids=set()
for p in (SOURCES/BASE/'ext').glob('potentialtable*.dnt'):
 d=DNT(p)
 potential_pairs.update((v['_PotentialID'],v['_PotentialNo']) for v in d.rows.values());potential_ids.update(v['_PotentialID'] for v in d.rows.values())
weapon={k:v for p in (SOURCES/BASE/'ext').glob('weapontable*.dnt') for k,v in DNT(p).rows.items()}
parts={k:v for p in (SOURCES/BASE/'ext').glob('partstable*.dnt') for k,v in DNT(p).rows.items()}
setids={k for p in (SOURCES/BASE/'ext').glob('setitemtable*.dnt') for k in DNT(p).rows}
enchantids={v['_EnchantID'] for p in (SOURCES/BASE/'ext').glob('enchanttable*.dnt') for v in DNT(p).rows.values()}
added=defaultdict(dict);selected=[];skipped=[];conflicts=[]
seen_payloads={tuple(v[n] for n,t in craft[BASE][name].cols) for name,v in recipes.values()}
for s in DONORS:
 for name,d in craft[s].items():
  if not name.startswith('itemcompoundtable'):continue
  assert name in craft[BASE],name
  assert d.cols==craft[BASE][name].cols,name
  assert not d.duplicates
  for k,v in d.rows.items():
   info={'source':s,'table':name,'id':k,'output_item_id':v['_SuccessItemID1'],'group_id':v['_CompoundGroupID']}
   if k in recipes:
    bn,bv=recipes[k]
    if k in base_recipe_ids and v!=bv:
     conflicts.append({**info,'retained_table':bn,'different_fields':';'.join(n for n in v if v[n]!=bv[n])})
    continue
   reason='';detail=''
   missing=sorted({x for x in deps(v) if x not in items})
   if missing:reason='missing_item_in_556';detail=';'.join(map(str,missing))
   elif any(items[x].get('_isUse',1)!=1 for x in deps(v)):
    reason='item_disabled_in_556';detail=';'.join(str(x) for x in deps(v) if items[x].get('_isUse',1)!=1)
   elif not (math.isfinite(v['_Possibility']) and 0<v['_Possibility']<=1 and v['_Cost']>=0 and math.isfinite(v['_TimeRequired']) and v['_TimeRequired']>=0):
    reason='invalid_probability_cost_or_time'
   elif any(v[f'_Slot{i}Id']>0 and v[f'_Slot{i}Num']<=0 for i in range(1,6)):
    reason='invalid_material_quantity'
   else:
    output=items[v['_SuccessItemID1']];no=v['_CompoundPotentialID']
    if no>0 and not any((x,no) in potential_pairs for x in refs(output) if x>0):
     reason='missing_output_potential_in_556';detail=f'potential_no={no};item_potential_groups='+','.join(map(str,refs(output)))
    elif v['_CompoundPreliminaryID']>0:
     inp=items.get(v['_Slot1Id'],{});pre=v['_CompoundPreliminaryID']
     if not any((x,pre) in potential_pairs for x in refs(inp) if x>0):
      reason='missing_input_potential_in_556';detail=f'potential_no={pre}'
    if not reason:
     if v['_CompoundGroupID']>0 and v['_CompoundGroupID'] not in available_groupids and k not in shop_recipe_ids:
      reason='no_menu_group_in_any_archive'
     elif output['_Type'] in (0,1):
      obj=(weapon if output['_Type']==0 else parts).get(v['_SuccessItemID1'])
      if obj is None:reason='missing_equipment_object_in_556'
      elif obj.get('_SetItemID',0)>0 and obj['_SetItemID'] not in setids:reason='missing_set_bonus_in_556';detail=str(obj['_SetItemID'])
      elif output.get('_EnchantID',0)>0 and output['_EnchantID'] not in enchantids:reason='missing_enchant_group_in_556';detail=str(output['_EnchantID'])
   payload=tuple(v[n] for n,t in d.cols)
   if not reason and payload in seen_payloads:reason='identical_recipe_already_present'
   if reason:
    skipped.append({**info,'reason':reason,'detail':detail});continue
   recipes[k]=(name,v);added[name][k]=v;seen_payloads.add(payload);selected.append(info)
print('selected recipes',len(selected),'skipped candidates',len(skipped),flush=True)
# Main group table absorbs donor-only *_mcn; use filenames already loaded by 556.
seen_groups={group_identity(v) for n,k,v in base_groups};used_group_keys={k for n,k,v in base_groups}
group_keys={k for s,n,k,v in allgroups};next_group_key=max(group_keys|used_group_keys)+1
active_recipe_groups={v['_CompoundGroupID'] for n,v in recipes.values() if v['_CompoundGroupID']>0}
group_changes=[];group_skips=[]
for s,n,k,v in allgroups:
 if s==BASE:continue
 info={'source':s,'source_table':n,'source_id':k,'list_id':v['_ListID'],'group_id':v['_CompoundGroupID'],'main_category':v['_MainCategory'],'set_name_string_id':v['_SetID'],'level':v['_Level'],'job_class':v['_JobClass']}
 if group_identity(v) in seen_groups:continue
 if v['_CompoundGroupID'] not in active_recipe_groups:
  group_skips.append({**info,'reason':'no_valid_recipe'});continue
 target=n if n in craft[BASE] else 'itemcompoundgrouptable.dnt'
 assert craft[BASE][target].cols==craft[s][n].cols
 key=k
 if key in used_group_keys:
  while next_group_key in used_group_keys or next_group_key in group_keys:next_group_key+=1
  key=next_group_key;next_group_key+=1
 assert key<2**31
 used_group_keys.add(key);seen_groups.add(group_identity(v));added[target][key]=v
 group_changes.append({**info,'target_table':target,'target_id':key})
for name,rows in added.items():
 craft[BASE][name].write(EXT/name,rows)
print('added groups',len(group_changes),'modified tables',list(added),flush=True)
# Verify exact source preservation, format, uniqueness and intended additions.
validation={'base_rows_preserved':True,'base_schemas_preserved':True,'unique_recipe_ids':True,'unique_new_group_row_ids':True,'new_recipe_item_references_present':True,'new_positive_potentials_resolved':True,'new_recipe_menu_links_resolved':True,'zip_crc_checked':False,'server_and_client_runtime_tested':False}
changes=[];final_recipe_ids=set();finalgroups=set();final_tables={}
for name,rows in added.items():
 before=craft[BASE][name];after=DNT(EXT/name);final_tables[name]=after
 assert before.cols==after.cols
 assert not after.duplicates
 for k in before.order:assert before.raw[k]==after.raw[k],(name,k,'base row altered')
 for k,v in rows.items():assert after.rows[k]==v,(name,k,'new row mismatch')
 assert len(after.order)==len(before.order)+len(rows)
 changes.append({'file':name,'before_rows':len(before.order),'added_rows':len(rows),'after_rows':len(after.order),'before_sha256':sha(before.path),'after_sha256':sha(EXT/name)})
for p in EXT.glob('itemcompoundtable*.dnt'):
 d=final_tables.get(p.name) or DNT(p)
 assert not (set(d.rows)&final_recipe_ids),(p,'global recipe ID collision')
 final_recipe_ids.update(d.rows)
for p in EXT.glob('itemcompoundgrouptable*.dnt'):
 d=final_tables.get(p.name) or DNT(p);finalgroups.update(v['_CompoundGroupID'] for v in d.rows.values())
for info in selected:
 v=added[info['table']][info['id']]
 assert all(x in items for x in deps(v))
 if v['_CompoundGroupID']>0:assert v['_CompoundGroupID'] in finalgroups or info['id'] in shop_recipe_ids,('new recipe without menu',info)
for p in (SOURCES/BASE/'ext').rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(SOURCES/BASE/'ext')
 if rel.as_posix() not in added:assert sha(p)==sha(EXT/rel),('unintended file change',rel)
counts={'base_recipes':base_recipe_count,'added_recipes':len(selected),'total_recipes':len(final_recipe_ids),'base_menu_rows':len(base_groups),'added_menu_rows':len(group_changes),'total_menu_rows':len(base_groups)+len(group_changes),'added_recipes_by_table':dict(Counter(x['table'] for x in selected)),'skipped_candidates_by_reason':dict(Counter(x['reason'] for x in skipped)),'added_menu_rows_by_level':dict(sorted(Counter(x['level'] for x in group_changes).items())),'changed_files':len(changes),'recipe_id_conflicts_retained_from_556':len(conflicts),'group_row_id_remaps':sum(x['source_id']!=x['target_id'] for x in group_changes)}
setrows=[x for x in selected if x['table']=='itemcompoundtable_set.dnt'];eqids={x['output_item_id'] for x in setrows};actualsetids={o.get('_SetItemID',0) for k in eqids for o in [weapon.get(k) or parts.get(k) or {}] if o.get('_SetItemID',0)>0}
counts['added_set_recipe_unique_outputs']=len(eqids);counts['added_set_recipe_set_bonus_ids']=len(actualsetids)
counts['added_ordinary_set_menu_name_ids']=len({x['set_name_string_id'] for x in group_changes if x['main_category']==0 and x['set_name_string_id']>0})
report={'base':'ext556.rar','donor_order':['ext2.rar','ext.rar'],'identical_donors':['ext.rar','ext3.rar','ext4.rar'],'merge_policy':'Preserve every ext556 row and schema. Add only recipes with existing enabled 556 items, valid quantities, positive potential pairs present in 556, existing object/set/enchant dependencies, and existing donor/base menu groups. Fold donor-only menu table into existing main table. Preserve 556 conflicting IDs. No item/stat/drop/NPC/skill changes. Unknown client assets and localization are unverified.','counts':counts,'modified_tables':changes,'validation':validation,'base_item_id_duplicates':itemdups}
(REPORT/'summary.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
csvwrite('added_recipes.csv',selected,['source','table','id','output_item_id','group_id'])
csvwrite('skipped_recipes.csv',skipped,['source','table','id','output_item_id','group_id','reason','detail'])
csvwrite('retained_556_conflicts.csv',conflicts,['source','table','id','output_item_id','group_id','retained_table','different_fields'])
fields=['source','source_table','source_id','list_id','group_id','main_category','set_name_string_id','level','job_class']
csvwrite('added_menu_groups.csv',group_changes,fields+['target_table','target_id'])
csvwrite('skipped_menu_groups.csv',group_skips,fields+['reason'])
print(json.dumps(counts,ensure_ascii=False,indent=2),flush=True)
