from pathlib import Path
import struct
class DNT:
 def __init__(self,path):
  self.path=Path(path); self.data=b=self.path.read_bytes(); self.magic,c,r=struct.unpack_from('<IHI',b); o=10; self.cols=[]
  for _ in range(c):
   n=struct.unpack_from('<H',b,o)[0];o+=2;name=b[o:o+n].decode('ascii');o+=n;t=b[o];o+=1;self.cols.append((name,t))
  self.header=b[:o]; self.rows={}; self.order=[]; self.raw={}; self.duplicates=[]
  for _ in range(r):
   start=o; key=struct.unpack_from('<i',b,o)[0];o+=4;row={}
   for name,t in self.cols:
    if t==1:
     n=struct.unpack_from('<H',b,o)[0];o+=2;v=b[o:o+n];o+=n
    elif t in (2,3):v=struct.unpack_from('<i',b,o)[0];o+=4
    elif t==6:v=struct.unpack_from('<q',b,o)[0];o+=8
    elif t==4:v=struct.unpack_from('<f',b,o)[0];o+=4
    elif t==5:v=struct.unpack_from('<f',b,o)[0];o+=4
    else:raise ValueError((self.path,name,t,o))
    row[name]=v
   if key in self.rows:self.duplicates.append(key)
   self.rows[key]=row;self.order.append(key);self.raw[key]=b[start:o]
  self.footer=b[o:]
  if self.footer!=b'\x05THEND':raise ValueError((self.path,'unexpected footer',o,len(b),self.footer[:20]))
 def encode(self,key,row):
  b=struct.pack('<i',key)
  for name,t in self.cols:
   v=row[name]
   if t==1:b+=struct.pack('<H',len(v))+v
   else:b+=struct.pack({2:'<i',3:'<i',4:'<f',5:'<f',6:'<q'}[t],v)
  return b
 def write(self,path,added=None,replacements=None):
  added=added or {};replacements=replacements or {}
  h=bytearray(self.header);struct.pack_into('<I',h,6,len(self.order)+len(added))
  body=[self.encode(k,replacements[k]) if k in replacements else self.raw[k] for k in self.order]
  body.extend(self.encode(k,v) for k,v in added.items())
  Path(path).write_bytes(h+b''.join(body)+self.footer)
